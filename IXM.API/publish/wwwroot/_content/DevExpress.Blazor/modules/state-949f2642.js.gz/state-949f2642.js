import{e as r}from"./property-d3853089.js";function t(t){return r({...t,state:!0})}export{t};
